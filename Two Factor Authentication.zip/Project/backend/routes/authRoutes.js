// routes/authRoutes.js

import express from 'express';
import bcrypt from 'bcryptjs';
import nodemailer from 'nodemailer';
import User from '../models/user.js';
import Otp from '../models/otp.js';

const router = express.Router();

// Email setup
console.log("✅ Using email user:", process.env.EMAIL_USER);
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

// Helper to send OTP email
const sendOtp = async (email, code) => {
  await transporter.sendMail({
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'Your OTP Code',
    text: `Your OTP code is: ${code}`,
  });
};

// -------- REGISTER --------
router.post('/register', async (req, res) => {
  try {
    const { fullName, email, password, confirmpassword } = req.body;
    console.log("🟡 Register request:", req.body);

    if (!fullName || !email || !password || !confirmpassword) {
      return res.status(400).json({ message: "All fields are required" });
    }

    if (password !== confirmpassword) {
      return res.status(400).json({ message: "Passwords do not match" });
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(400).json({ message: "User already exists" });

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ fullName, email, password: hashedPassword });
    await user.save();

    res.status(201).json({ message: "Registered successfully" });
  } catch (err) {
    console.error("❌ Register error:", err);
    res.status(500).json({ message: "Server error during registration" });
  }
});

// -------- LOGIN & SEND OTP --------
router.post('/login', async (req, res) => {
  try {
    console.log("🟡 Login request:", req.body);

    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: "Email and password required" });
    }

    const user = await User.findOne({ email });
    console.log("🔍 Found user:", user);

    if (!user) return res.status(404).json({ message: "User not found" });

    const isMatch = await bcrypt.compare(password, user.password);
    console.log("✅ Password match:", isMatch);

    if (!isMatch) return res.status(401).json({ message: "Invalid credentials" });

    const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
    await Otp.create({ email, code: otpCode });

    await sendOtp(email, otpCode);

    res.status(200).json({ message: "OTP sent", email });
  } catch (err) {
    console.error("❌ Login error:", err);
    res.status(500).json({ message: "Server error during login" });
  }
});

// -------- VERIFY OTP --------
router.post('/verify-otp', async (req, res) => {
  try {
    const { email, otp } = req.body;
    console.log("🟡 OTP verify for:", email, "Code:", otp);

    if (!email || !otp) {
      return res.status(400).json({ message: "Email and OTP required" });
    }

    const record = await Otp.findOne({ email, code: otp });
    if (!record) return res.status(400).json({ message: "Invalid or expired OTP" });

    await Otp.deleteMany({ email });
    res.status(200).json({ message: "OTP verified" });
  } catch (err) {
    console.error("❌ OTP verification error:", err);
    res.status(500).json({ message: "Server error during OTP verification" });
  }
});

// -------- RESEND OTP --------
router.post('/resend-otp', async (req, res) => {
  try {
    const { email } = req.body;
    console.log("🟡 Resend OTP for:", email);

    if (!email) {
      return res.status(400).json({ message: "Email is required" });
    }

    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: "User not found" });

    // Delete old OTPs
    await Otp.deleteMany({ email });

    // Generate new OTP
    const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
    await Otp.create({ email, code: otpCode });

    await sendOtp(email, otpCode);

    res.status(200).json({ message: "New OTP sent successfully" });
  } catch (err) {
    console.error("❌ Resend OTP error:", err);
    res.status(500).json({ message: "Server error while resending OTP" });
  }
});

export default router;