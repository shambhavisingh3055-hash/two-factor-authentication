import nodemailer from "nodemailer";
import dotenv from "dotenv";
dotenv.config();

// Named export so you can import { sendOTPEmail }
export const sendOTPEmail = async (to, otp) => {
  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: process.env.EMAIL_USER, // your Gmail address from .env
      pass: process.env.EMAIL_PASS, // app-specific password from .env
    },
  });

  const mailOptions = {
    from: `"2FA Auth App" <${process.env.EMAIL_USER}>`,
    to: to,
    subject: "Your OTP Code for 2FA Login",
    text: `Your One-Time Password (OTP) is: ${otp}. It is valid for 5 minutes.`,
  };

  await transporter.sendMail(mailOptions);
};
