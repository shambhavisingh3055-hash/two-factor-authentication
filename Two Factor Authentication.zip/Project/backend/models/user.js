import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  fullName: String,
  email: { type: String, unique: true, required: true },
   contact: {type: String, required: true, match: /^[0-9]{10}$/, },
  password: { type: String, required: true },
}, { timestamps: true });

export default mongoose.model('User', userSchema);