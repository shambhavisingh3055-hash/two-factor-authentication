import express from 'express';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import nodemailer from 'nodemailer';

dotenv.config();

const app = express();
const PORT = 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Email setup
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

// Simple User and OTP storage (in production, use proper models)
const users = [];
const otps = [];

// Helper to send OTP email
const sendOtp = async (email, code) => {
  try {
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'Your OTP Code',
      text: `Your OTP code is: ${code}`,
    });
  } catch (error) {
    console.error('Email send error:', error);
  }
};

// Root route
app.get('/', (req, res) => {
  res.json({ message: '2FA Auth Server Running' });
});

// Register route
app.post('/api/auth/register', async (req, res) => {
  try {
    const { fullName, email, password, confirmpassword } = req.body;
    console.log("Register request:", { fullName, email });

    if (!fullName || !email || !password || !confirmpassword) {
      return res.status(400).json({ message: "All fields are required" });
    }

    if (password !== confirmpassword) {
      return res.status(400).json({ message: "Passwords do not match" });
    }

    const existingUser = users.find(u => u.email === email);
    if (existingUser) {
      return res.status(400).json({ message: "User already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    users.push({ fullName, email, password: hashedPassword });

    console.log("User registered successfully:", email);
    res.status(201).json({ message: "Registered successfully" });
  } catch (err) {
    console.error("Register error:", err);
    res.status(500).json({ message: "Server error during registration" });
  }
});

// Login route
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    console.log("Login request:", email);

    if (!email || !password) {
      return res.status(400).json({ message: "Email and password required" });
    }

    const user = users.find(u => u.email === email);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
    otps.push({ email, code: otpCode, timestamp: Date.now() });

    await sendOtp(email, otpCode);
    console.log("OTP sent to:", email, "Code:", otpCode);

    res.status(200).json({ message: "OTP sent", email });
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ message: "Server error during login" });
  }
});

// Verify OTP route
app.post('/api/auth/verify-otp', (req, res) => {
  try {
    const { email, otp } = req.body;
    console.log("OTP verify for:", email, "Code:", otp);

    if (!email || !otp) {
      return res.status(400).json({ message: "Email and OTP required" });
    }

    const otpIndex = otps.findIndex(o => o.email === email && o.code === otp);
    if (otpIndex === -1) {
      return res.status(400).json({ message: "Invalid or expired OTP" });
    }

    otps.splice(otpIndex, 1); // Remove used OTP
    res.status(200).json({ message: "OTP verified", token: "dummy-token" });
  } catch (err) {
    console.error("OTP verification error:", err);
    res.status(500).json({ message: "Server error during OTP verification" });
  }
});

// Resend OTP route
app.post('/api/auth/resend-otp', async (req, res) => {
  try {
    const { email } = req.body;

    const user = users.find(u => u.email === email);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Remove old OTPs for this email
    const filteredOtps = otps.filter(o => o.email !== email);
    otps.length = 0;
    otps.push(...filteredOtps);

    const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
    otps.push({ email, code: otpCode, timestamp: Date.now() });

    await sendOtp(email, otpCode);
    console.log("New OTP sent to:", email, "Code:", otpCode);

    res.status(200).json({ message: "New OTP sent successfully" });
  } catch (err) {
    console.error("Resend OTP error:", err);
    res.status(500).json({ message: "Server error while resending OTP" });
  }
});

// MongoDB connection (optional - using arrays for now)
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('✅ MongoDB Connected'))
  .catch(err => console.log('❌ MongoDB Error:', err));

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log(`📧 Email configured: ${process.env.EMAIL_USER}`);
});