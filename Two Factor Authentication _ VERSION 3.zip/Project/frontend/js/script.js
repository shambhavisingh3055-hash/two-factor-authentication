const backendURL = "http://localhost:3001/api";

// Helper functions for showing/hiding errors
function showError(elementId, message) {
  const errorElement = document.getElementById(elementId);
  if (errorElement) {
    errorElement.textContent = message;
    errorElement.style.display = 'block';
    errorElement.parentElement.classList.add('shake');
    setTimeout(() => {
      errorElement.parentElement.classList.remove('shake');
    }, 500);
  }
}

function hideError(elementId) {
  const errorElement = document.getElementById(elementId);
  if (errorElement) {
    errorElement.style.display = 'none';
  }
}

function showSuccess(message) {
  const successElement = document.getElementById('successMessage');
  if (successElement) {
    successElement.textContent = message;
    successElement.style.display = 'block';
  }
}

// Register Form Handler
const registerForm = document.getElementById("registerForm");
if (registerForm) {
  const passwordToggle = document.getElementById("passwordToggle");
  
  // Password visibility toggle
  if (passwordToggle) {
    passwordToggle.addEventListener('click', function() {
      const passwordInput = document.getElementById("password");
      const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
      passwordInput.setAttribute('type', type);
      
      const eyeIcon = passwordToggle.querySelector('.eye-icon');
      const eyeOffIcon = passwordToggle.querySelector('.eye-off-icon');
      
      if (type === 'password') {
        eyeIcon.style.display = 'block';
        eyeOffIcon.style.display = 'none';
      } else {
        eyeIcon.style.display = 'none';
        eyeOffIcon.style.display = 'block';
      }
    });
  }

  registerForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    
    // Clear previous errors
    hideError("fullNameError");
    hideError("emailError");
    hideError("contactError");
    hideError("passwordError");
    hideError("confirmPasswordError");
    
    const fullName = document.getElementById("fullName").value.trim();
    const email = document.getElementById("email").value.trim();
    const contact = document.getElementById("contact").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;
    
    // Client-side validation
    let isValid = true;
    
    if (!fullName) {
      showError("fullNameError", "Full name is required");
      isValid = false;
    }
    
    if (!email) {
      showError("emailError", "Email is required");
      isValid = false;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      showError("emailError", "Please enter a valid email address");
      isValid = false;
    }
    
    if (!contact) {
      showError("contactError", "Contact number is required");
      isValid = false;
    } else if (!/^[0-9]{10}$/.test(contact)) {
      showError("contactError", "Please enter a valid 10-digit phone number");
      isValid = false;
    }
    
    if (!password) {
      showError("passwordError", "Password is required");
      isValid = false;
    } else if (password.length < 8) {
      showError("passwordError", "Password must be at least 8 characters");
      isValid = false;
    }
    
    if (!confirmPassword) {
      showError("confirmPasswordError", "Please confirm your password");
      isValid = false;
    } else if (password !== confirmPassword) {
      showError("confirmPasswordError", "Passwords do not match");
      isValid = false;
    }
    
    if (!isValid) return;
    
    try {
      console.log("Sending registration data:", { fullName, email, contact, password: "***" });
      const response = await fetch(`${backendURL}/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName,
          email,
          contact,
          password,
          confirmpassword: confirmPassword,
        }),
      });
      console.log("Response status:", response.status);
      const data = await response.json();
      console.log("Response data:", data);
      if (response.ok) {
        showSuccess("Registration successful! Redirecting to login...");
        setTimeout(() => {
          window.location.href = "login.html";
        }, 2000);
      } else {
        // Show server validation errors in appropriate fields
        if (data.message.includes("email")) {
          showError("emailError", data.message);
        } else if (data.message.includes("contact")) {
          showError("contactError", data.message);
        } else if (data.message.includes("password")) {
          showError("passwordError", data.message);
        } else {
          alert(data.message || "Registration failed");
        }
      }
    } catch (error) {
      console.error("Registration error:", error);
      alert("An error occurred during registration");
    }
  });
}

// Login Form Handler
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  const passwordToggle = document.getElementById("passwordToggle");
  
  // Password visibility toggle
  if (passwordToggle) {
    passwordToggle.addEventListener('click', function() {
      const passwordInput = document.getElementById("password");
      const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
      passwordInput.setAttribute('type', type);
      
      const eyeIcon = passwordToggle.querySelector('.eye-icon');
      const eyeOffIcon = passwordToggle.querySelector('.eye-off-icon');
      
      if (type === 'password') {
        eyeIcon.style.display = 'block';
        eyeOffIcon.style.display = 'none';
      } else {
        eyeIcon.style.display = 'none';
        eyeOffIcon.style.display = 'block';
      }
    });
  }

  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    
    // Clear previous errors
    hideError("emailError");
    hideError("passwordError");
    
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    
    // Client-side validation
    let isValid = true;
    
    if (!email) {
      showError("emailError", "Email is required");
      isValid = false;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      showError("emailError", "Please enter a valid email address");
      isValid = false;
    }
    
    if (!password) {
      showError("passwordError", "Password is required");
      isValid = false;
    }
    
    if (!isValid) return;
    
    try {
      const response = await fetch(`${backendURL}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await response.json();
      if (response.ok) {
        localStorage.setItem("userEmail", email);
        showSuccess("Login successful! Redirecting to OTP verification...");
        setTimeout(() => {
          window.location.href = "otp.html";
        }, 2000);
      } else {
        // Show server validation errors in appropriate fields
        if (data.message.includes("email")) {
          showError("emailError", data.message);
        } else if (data.message.includes("password")) {
          showError("passwordError", data.message);
        } else {
          alert(data.message || "Login failed");
        }
      }
    } catch (error) {
      console.error("Login error:", error);
      alert("An error occurred during login");
    }
  });
}

// OTP Form Handler
const otpForm = document.getElementById("otpForm");
if (otpForm) {
  otpForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    
    // Clear previous errors
    hideError("otpError");
    
    const email = localStorage.getItem("userEmail");
    const otp = document.getElementById("otp").value.trim();
    
    // Client-side validation
    let isValid = true;
    
    if (!otp) {
      showError("otpError", "OTP is required");
      isValid = false;
    } else if (!/^[0-9]{6}$/.test(otp)) {
      showError("otpError", "Please enter a valid 6-digit OTP");
      isValid = false;
    }
    
    if (!isValid) return;
    
    try {
      const response = await fetch(`${backendURL}/auth/verify-otp`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, otp }),
      });
      const data = await response.json();
      if (response.ok) {
        localStorage.setItem("authToken", data.token);
        showSuccess("OTP verified successfully! Redirecting to dashboard...");
        setTimeout(() => {
          window.location.href = "dashboard.html";
        }, 2000);
      } else {
        // Show server validation errors in appropriate fields
        if (data.message.includes("OTP")) {
          showError("otpError", data.message);
        } else {
          alert(data.message || "OTP verification failed");
        }
      }
    } catch (error) {
      console.error("OTP verification error:", error);
      alert("An error occurred during OTP verification");
    }
  });
  
  // Resend OTP handler
  const resendBtn = document.getElementById("resendOtp");
  if (resendBtn) {
    resendBtn.addEventListener("click", async () => {
      const email = localStorage.getItem("userEmail");
      
      try {
        const response = await fetch(`${backendURL}/auth/resend-otp`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email }),
        });
        const data = await response.json();
        if (response.ok) {
          alert(data.message || "New OTP sent successfully!");
          // Start countdown
          startCountdown(30);
        } else {
          throw new Error(data.message || "Failed to resend OTP");
        }
      } catch (error) {
        console.error("Resend OTP error:", error);
        alert(error.message);
      }
    });
  }
  
  // Countdown function for OTP resend
  function startCountdown(seconds) {
    const resendBtn = document.getElementById("resendOtp");
    const countdown = document.getElementById("countdown");
    
    if (!resendBtn || !countdown) return;
    
    let timeLeft = seconds;
    resendBtn.disabled = true;
    resendBtn.textContent = 'Resend OTP';
    countdown.style.display = 'block';
    
    const countdownTimer = setInterval(() => {
      timeLeft--;
      countdown.textContent = `Resend available in ${timeLeft}s`;
      
      if (timeLeft <= 0) {
        clearInterval(countdownTimer);
        resendBtn.disabled = false;
        countdown.style.display = 'none';
      }
    }, 1000);
  }
  
  // Initialize countdown on page load
  startCountdown(30);
}

// Dashboard functionality
const emailDisplay = document.getElementById("userEmail");
if (emailDisplay) {
  const userEmail = localStorage.getItem("userEmail");
  emailDisplay.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
      <polyline points="22,6 12,13 2,6"></polyline>
    </svg>
    ${userEmail || "Guest"}
  `;
}

const logoutBtn = document.getElementById("logoutBtn");
if (logoutBtn) {
  logoutBtn.addEventListener("click", () => {
    localStorage.removeItem("authToken");
    localStorage.removeItem("userEmail");
    window.location.href = "login.html";
  });
}

// Add click handlers for dashboard menu items
const menuItems = document.querySelectorAll(".menu-item");
if (menuItems.length > 0) {
  menuItems.forEach(item => {
    item.addEventListener("click", function() {
      const title = this.querySelector(".menu-title").textContent;
      alert(`You clicked on ${title}. This would navigate to the ${title} page.`);
    });
  });
}