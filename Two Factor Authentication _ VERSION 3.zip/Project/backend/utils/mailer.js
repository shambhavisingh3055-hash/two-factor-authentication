import nodemailer from "nodemailer";
import dotenv from "dotenv";
dotenv.config();

export const sendOTPEmail = async (to, otp) => {
  const transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,              // Use 465 for SSL
    secure: true,           // Must be true for port 465
    auth: {
      user: process.env.EMAIL_USER, // Your Gmail address
      pass: process.env.EMAIL_PASS, // App Password (16 chars)
    },
    tls: {
      rejectUnauthorized: false, // Prevents TLS handshake errors
    },
  });

  const mailOptions = {
    from: `"2FA Auth App" <${process.env.EMAIL_USER}>`,
    to,
    subject: "Your OTP Code for 2FA Login",
    text: `Your One-Time Password (OTP) is: ${otp}. It is valid for 5 minutes.`,
  };

  await transporter.sendMail(mailOptions);
};
